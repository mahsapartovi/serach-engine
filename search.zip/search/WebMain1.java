import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;


import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

public class WebMain {
    public static Set<String> all_tokens;
    public static ArrayList<String> final_ans;
    public static ArrayList<Integer> final_score;



    public static void findBest(ArrayList<String> ans, ArrayList<Integer> score, int i, String sentence, int score_sum){
        if(i > score.size()){
            final_ans.add(sentence);
            final_score.add(score_sum);
            return;
        }
        int next = i + 10;
        for(int k=i-10;k<i;k++){
            findBest(ans, score, next, sentence + " " + ans.get(k), score_sum + score.get(k));
        }
    }


    public static ArrayList<String> findMistake(String search){

        String[] tokens = PreProcess.tokenize(search);
        EditDistance dist;
        ArrayList<String> words = new ArrayList<String>();
        ArrayList<Integer> score = new ArrayList<Integer>();
        ArrayList<String> ans = new ArrayList<String>();
        ArrayList<Integer> ans_score = new ArrayList<Integer>();

        for(int k=0;k<tokens.length;k++){
            words.clear();
            score.clear();
            for (String a : all_tokens){
                dist = new EditDistance(tokens[k].trim(), a);
                words.add(a);
                score.add((int)dist.distance());
            }

            for(int i=0;i<10;i++){
                int min = 1000;
                int index = -1;
                for(int j=0;j<score.size();j++){
                    if(score.get(j) < min){
                        min = score.get(j);
                        index = j;
                    }
                }
                ans.add(words.get(index));
                ans_score.add(score.get(index));
                words.remove(index);
                score.remove(index);
            }

        }

        final_ans.clear();
        final_score.clear();
        findBest(ans, ans_score, 10, "", 0);
        ArrayList<String> out = new ArrayList<String>();

        for(int i=0;i<10;i++){
            int min = 10000;
            int index = -1;
            for(int j=0;j<final_score.size();j++){
                if(final_score.get(j) < min){
                    min = final_score.get(j);
                    index = j;
                }
            }
            out.add(final_ans.get(index));
            final_ans.remove(index);
            final_score.remove(index);
        }


        return out;
    }



    public static void main(String[] args) throws Exception {
        final_ans = new ArrayList<String>();
        final_score = new ArrayList<Integer>();

        BufferedReader reader;
        all_tokens = new HashSet<String>();
        try {
            int l=0;
			reader = new BufferedReader(new FileReader("input.txt"));
			String line = reader.readLine();
    		while (line != null) {
                String[] tokens = PreProcess.tokenize(line);
                for(int i=0;i<tokens.length;i++){
                    all_tokens.add(tokens[i].trim());
                }
                line = reader.readLine();
			}
            System.out.println(all_tokens.size());
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

        System.out.println("server is runing!");
        System.out.println("open http://localhost:8000/test");
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/test", new MyHandler());
        server.setExecutor(null); // creates a default executor
        server.start();
    }

    static class MyHandler implements HttpHandler {

        public Map<String, String> queryToMap(String query) {
            Map<String, String> result = new HashMap<>();
            for (String param : query.split("&")) {
                String[] entry = param.split("=");
                if (entry.length > 1) {
                    result.put(entry[0], entry[1]);
                }else{
                    result.put(entry[0], "");
                }
            }
            return result;
        }

        @Override
        public void handle(HttpExchange t) throws IOException {
            String out="";
            if(t.getRequestURI().getQuery() != null){
                Map <String, String> query = queryToMap(t.getRequestURI().getQuery());
                ArrayList <String> ans = findMistake(query.get("search"));
                for(int i=0;i<ans.size();i++){
                    out += ans.get(i) + "</br>";
                }
            }
            String response = "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><title>search page</title></head><body><form method=\"get\"><input type=\"text\" name=\"search\" id=\"search\"><input type=\"submit\" value=\"search\"></form>"+ out +"</body></html>";

            byte[] bs = response.getBytes("UTF-8");
            t.sendResponseHeaders(200, bs.length);
            OutputStream os = t.getResponseBody();
            os.write(bs);
            os.close();
        }
    }

}